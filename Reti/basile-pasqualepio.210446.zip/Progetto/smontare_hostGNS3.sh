#!/bin/sh

fusermount -u /home/ppbit378/Scrivania/Reti/Progetto/F1
fusermount -u /home/ppbit378/Scrivania/Reti/Progetto/F2
fusermount -u /home/ppbit378/Scrivania/Reti/Progetto/R2
