#!/bin/sh

sshfs root@10.0.4.146:/ /home/ppbit378/Scrivania/Reti/Progetto/F1/
sshfs root@10.0.4.138:/ /home/ppbit378/Scrivania/Reti/Progetto/F2/
sshfs root@10.0.4.142:/ /home/ppbit378/Scrivania/Reti/Progetto/R2/
